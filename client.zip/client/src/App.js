import './App.css';
import Dashboard from './components/Dashboard';

function App() {
  return (
    <div className='App' style={{padding:"20px"}}>
     <Dashboard/>
    </div>
  );
}

export default App;
